// Troque pelo número real do buffet (código do país + DDD + número, só dígitos)
const WHATSAPP = "5519900000000";

document.getElementById("ano").textContent = new Date().getFullYear();

// menu mobile
const menu = document.getElementById("menu");
document.getElementById("menuBtn").addEventListener("click", () => menu.classList.toggle("open"));
menu.querySelectorAll("a").forEach(a => a.addEventListener("click", () => menu.classList.remove("open")));

// botões "Quero esse" já selecionam o pacote
document.querySelectorAll("[data-pack]").forEach(btn =>
  btn.addEventListener("click", () => { document.getElementById("pacote").value = btn.dataset.pack; })
);

// data mínima = hoje
document.getElementById("data").min = new Date().toISOString().split("T")[0];

// formulário -> WhatsApp
document.getElementById("form").addEventListener("submit", e => {
  e.preventDefault();
  const v = id => document.getElementById(id).value.trim();
  const [a, m, d] = v("data").split("-");
  const texto =
    `Olá! Gostaria de um orçamento para festa infantil.\n\n` +
    `Responsável: ${v("nome")}\n` +
    `Aniversariante: ${v("crianca")} (${v("idade")} anos)\n` +
    `Data: ${d}/${m}/${a}\n` +
    `Convidados: ${v("convidados")}\n` +
    `Pacote: ${v("pacote")}\n` +
    (v("msg") ? `Observações: ${v("msg")}` : "");
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(texto)}`, "_blank");
});
